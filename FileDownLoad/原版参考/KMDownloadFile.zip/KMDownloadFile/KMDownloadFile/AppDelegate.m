//
//  AppDelegate.m
//  KMDownloadFile
//
//  Created by KenmuHuang on 15/9/1.
//  Copyright (c) 2015年 Kenmu. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    _window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    ViewController *viewController = [[ViewController alloc]
                                      initWithSampleNameArray:@[ kTitleOfNSURLConnection,
                                                                 kTitleOfNSURLConnectionDelegate,
                                                                 kTitleOfNSURLSession,
                                                                 kTitleOfNSURLSessionDelegate,
                                                                 kTitleOfAFNetworking]];
    _navigationController = [[UINavigationController alloc] initWithRootViewController:viewController];
    _window.rootViewController = _navigationController;
    //[_window addSubview:_navigationController.view]; //当_window.rootViewController关联时，这一句可有可无
    [_window makeKeyAndVisible];
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
}

- (void)applicationWillTerminate:(UIApplication *)application {
}

@end
