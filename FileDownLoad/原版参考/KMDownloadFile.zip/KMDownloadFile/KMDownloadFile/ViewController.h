//
//  ViewController.h
//  KMDownloadFile
//
//  Created by KenmuHuang on 15/9/1.
//  Copyright (c) 2015年 Kenmu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UITableViewController
@property (copy, nonatomic) NSArray *arrSampleName;

- (instancetype)initWithSampleNameArray:(NSArray *)arrSampleName;

@end

