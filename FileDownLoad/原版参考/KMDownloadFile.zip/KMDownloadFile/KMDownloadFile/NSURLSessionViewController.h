//
//  NSURLSessionViewController.h
//  KMDownloadFile
//
//  Created by KenmuHuang on 15/9/3.
//  Copyright (c) 2015年 Kenmu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NSURLSessionViewController : UIViewController
@property (strong, nonatomic) IBOutlet UILabel *lblFileName;
@property (strong, nonatomic) IBOutlet UILabel *lblMessage;
@property (strong, nonatomic) IBOutlet UIButton *btnDownloadFile;

@end
